import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import Setroutes from './Setroutes.jsx'

function App() {
  

  return (
    <>
      <Setroutes/>
    </>
  )
}

export default App
