import React from 'react'

function LandingPages() {
  return (
    <div>
      Landing Page
    </div>
  )
}

export default LandingPages
